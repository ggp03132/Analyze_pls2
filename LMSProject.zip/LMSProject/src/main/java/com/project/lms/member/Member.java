package com.project.lms.member;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Member {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="memberno")
	private Integer memberno; //회원번호(수정불가)
	
	@Column(length =45,unique = true, nullable=false )
	private String memberid; //아이디(수정불가)
	
	@Column(length = 200)
	private String pwd;
	
	@Column(length = 45,nullable=false)
	private String name;
	
	@Column(length = 45,unique = true)
	private String cellnum;
	
	@Column(length = 45,nullable=false)
	private String birth;
	
	@Column(length = 45,unique = true, nullable=false)
	private String email;

	private Integer point;
	
	private String proimg;
	
	@Enumerated(EnumType.ORDINAL) //ORDINAL숫자로 저장
	private Role role;
	
	@CreatedDate
	private LocalDateTime creDate;
	
	@LastModifiedDate
	private LocalDateTime modDate;
	
}
