package com.project.lms.lesson;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.lms.course.Course;
import com.project.lms.course.CourseService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/lesson")
public class LessonController {

	private final LessonService lessonService;
	private final CourseService courseService;
	
	//전체 리스트
	@GetMapping("/list")
	public String list(Model model) {
		List<Lesson> lessonList = lessonService.getList();
		model.addAttribute("lessonList", lessonList);
		return "lessonListTest";
	}
	
	//하나 조회 (그 안에 다른 강의도 확인)
	@GetMapping("/detail/{lessonno}")
	public String detail(Model model, @PathVariable("lessonno") Integer lessonno) {
		Lesson lesson = lessonService.getLesson(lessonno);
		model.addAttribute("lesson", lesson);
		
		Course course = lesson.getCourse();
		model.addAttribute("course", course);
		model.addAttribute("lessonList", course.getLessonList());
		
//		if(lesson != null && lesson.getCourse() != null) {
//			Course course = lesson.getCourse();
//			model.addAttribute("course", course);
//			model.addAttribute("lessonList", course.getLessonList());
//		}
		
		return "lessonDetailTest";
	}
	
	//생성 정보 불러오기
	@GetMapping("/create/{courseno}")
	public String lessonCreate(Model model, @PathVariable("courseno") Integer courseno, LessonForm lessonForm) {
		Course course = courseService.getCourse(courseno);
		model.addAttribute("course", course);
		return "lessonCreateTest";
	}
	
	//생성하기
	@PostMapping("/create/{courseno}")
	public String lessonCreate(Model model, @PathVariable("courseno") Integer courseno, @Valid LessonForm lessonForm, BindingResult bindingResult) {
		Course course = courseService.getCourse(courseno);
		if(bindingResult.hasErrors()) {
			model.addAttribute("course", course);
			return "lessonCreateTest";
		}
		lessonService.create(lessonForm.getTitle(), lessonForm.getContent(), lessonForm.getVideo(), lessonForm.getTime(), course);
		return String.format("redirect:/course/detail/%s", courseno);
	}
	
	//수정 getmapping (조회)
	@GetMapping("/modify/{lessonno}")
	public String lessonModify(Model model, @PathVariable("lessonno") Integer lessonno) {
		Lesson lesson = lessonService.getLesson(lessonno);
		LessonForm lessonForm = new LessonForm();
		lessonForm.setTitle(lesson.getTitle());
		lessonForm.setContent(lesson.getContent());
		lessonForm.setVideo(lesson.getVideo());
		lessonForm.setTime(lesson.getTime());
		model.addAttribute("lessonForm", lessonForm);
		model.addAttribute("lesson", lesson);
		return "lessonModifyTest";
	}
	
	//수정 입력 (post)
	@PostMapping("/modify/{lessonno}")
	public String lessonModify(Model model, @PathVariable("lessonno") Integer lessonno, @Valid LessonForm lessonForm, BindingResult bindingResult) {
		Lesson lesson = lessonService.getLesson(lessonno);
		if(bindingResult.hasErrors()) {
			model.addAttribute("lesson", lesson);
			return "lessonModifyTest";
		}
		lessonService.modify(lesson, lessonForm.getTitle(), lessonForm.getContent(), lessonForm.getVideo(), lessonForm.getTime());
		return String.format("redirect:/lesson/detail/%s", lessonno);
	}
	
	//삭제
	@PostMapping("/delete/{lessonno}")
	public String lessonDelete(@PathVariable("lessonno") Integer lessonno) {
		Lesson lesson = lessonService.getLesson(lessonno);
		lessonService.delete(lesson);
		return String.format("redirect:/course/detail/%s", lesson.getCourse().getCourseno()); //course 컨트롤러랑 다르게 바로 return에 넣음
	}
}
