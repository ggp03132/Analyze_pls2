package com.project.lms.course;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.lms.category.Category;
import com.project.lms.category.CategoryService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/course")
public class CourseController {
	
	private final CourseService courseService;
	private final CategoryService categoryService;
	
	//전체 리스트 확인용
	@GetMapping("/list")
	public String list(Model model, @RequestParam(value="page", defaultValue = "0") int page) {
		List<Course> courseList = courseService.getList();
		model.addAttribute("courseList", courseList);
		return "course_list"; 
	}
	
	//상세조회
	@GetMapping("/detail/{courseno}")
	public String detail(Model model, @PathVariable("courseno") Integer courseno) {
		Course course = courseService.getCourse(courseno);
		model.addAttribute("course", course);
		return "course_detail";
	}
	
	//카테고리 상세에서 강좌등록을 눌렀을때 띄우는 get매핑
	@GetMapping("/create/{categoryno}")
	public String courseCreate(Model model, @PathVariable("categoryno") Integer categoryno, CourseForm courseForm) {
	    Category category = categoryService.getCategory(categoryno);
	    model.addAttribute("category", category);
	    return "course_create";
	}

	//강좌 생성 post 매핑
	@PostMapping("/create/{categoryno}")
	public String courseCreate(Model model, @PathVariable("categoryno") Integer categoryno, @Valid CourseForm courseForm, BindingResult bindingResult) {
		Category category = categoryService.getCategory(categoryno);
		if(bindingResult.hasErrors()) {
			model.addAttribute("category", category);
			return "course_create";
		}
		courseService.create(courseForm.getTitle(), courseForm.getContent(), courseForm.getCourseimg(), courseForm.getGrade(), courseForm.getBook(), courseForm.getBookimg(), category);
		return "redirect:/course/list";
	}
	
	//-------------
	//수정테스트 중 아직 테스트으ㅡ
    @GetMapping("/modify/{courseno}") //조회
    public String courseModify(Model model, @PathVariable("courseno") Integer courseno) {
        Course course = courseService.getCourse(courseno);
        CourseForm courseForm = new CourseForm();
        courseForm.setTitle(course.getTitle());
        courseForm.setContent(course.getContent());
        courseForm.setCourseimg(course.getCourseimg());
        courseForm.setGrade(course.getGrade());
        courseForm.setBook(course.getBook());
        courseForm.setBookimg(course.getBookimg());
        model.addAttribute("courseForm", courseForm);
        model.addAttribute("course", course);
        return "courseModifyTest";
    }
    
    @PostMapping("/modify/{courseno}") //수정
    public String courseModify(Model model, @PathVariable("courseno") Integer courseno, @Valid CourseForm courseForm, BindingResult bindingResult) {
        Course course = courseService.getCourse(courseno);
        if (bindingResult.hasErrors()) {
            model.addAttribute("course", course);
            return "courseModifyTest";
        }
        courseService.modify(course, courseForm.getTitle(), courseForm.getContent(), courseForm.getCourseimg(), courseForm.getGrade(), courseForm.getBook(), courseForm.getBookimg(), course.getCategory());
        return String.format("redirect:/course/detail/%s", courseno);
    }
    
    //삭제
    @PostMapping("/delete/{courseno}")
    public String courseDelete(@PathVariable("courseno") Integer courseno) {
    	Course course = courseService.getCourse(courseno);
    	Integer categoryno = course.getCategory().getCategoryno(); //categoryno에 강좌가 속한 카테고리 번호를 선언하고 return값에 넣음
    	courseService.delete(course);
    	return String.format("redirect:/category/detail/%s", categoryno);
    }
    
}
