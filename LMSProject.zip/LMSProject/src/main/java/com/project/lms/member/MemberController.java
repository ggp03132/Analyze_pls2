package com.project.lms.member;

import java.security.Principal;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/member")
public class MemberController {

	private final MemberService ms;
	private final MemberRepository mr;

//list
	@GetMapping("/list")
	public String list(Model model, @RequestParam(value = "page", defaultValue = "0") int page) {
		Page<Member> pm = ms.getList(page);
		model.addAttribute("pm", pm);
		return "member_list";
	}

//create	
	@GetMapping("/create")
	public String memberCreate(Model model) {
		model.addAttribute("memberForm", new MemberForm());
		return "member_form";
	}

	@PostMapping("/create")
	public String memberCreate(@Valid MemberForm memberForm, BindingResult bindingResult, Model model) {

		if (bindingResult.hasErrors()) {

			model.addAttribute("memberForm", memberForm);

			return "member_form";
		}
		if (ms.isIdDuplicated(memberForm.getMemberid(), memberForm.getMemberno())) {
			bindingResult.rejectValue("memberid", "duplicate", "이미 사용 중인 아이디입니다.");
			return "member_form";
		}
		if (ms.isCellnumDuplicated(memberForm.getCellnum(), memberForm.getMemberno())) {
			bindingResult.rejectValue("cellnum", "duplicate", "이미 사용 중인 휴대폰 번호입니다.");
			return "member_form";
		}
		if (ms.isEmailDuplicated(memberForm.getEmail(), memberForm.getMemberno())) {
			bindingResult.rejectValue("email", "duplicate", "이미 사용 중인 이메일입니다.");
			return "member_form";
		} else {
			ms.create(memberForm.getMemberid(), memberForm.getPwd(), memberForm.getName(), memberForm.getCellnum(),
					memberForm.getBirth(), memberForm.getEmail());
		}

		return "redirect:/member/list";
	}

//detail
	@GetMapping("/detail/{memberno}") // 이부분 id값이아니라 pk값으로 수정

	public String memberDetail(Model model, @PathVariable("memberno") Integer memberno) {
		if (memberno == null) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "회원 ID가 필요합니다.");
		}

		Member member = ms.getMember(memberno);

		MemberForm memberForm = new MemberForm();

		// 예시로 member 필드 값 복사
		memberForm.setMemberid(member.getMemberid());
		memberForm.setPwd(member.getPwd());
		memberForm.setName(member.getName());
		memberForm.setCellnum(member.getCellnum());
		memberForm.setBirth(member.getBirth());
		memberForm.setEmail(member.getEmail());

		model.addAttribute("memberForm", memberForm);
		model.addAttribute("member", member);
		
		return "member_detail";
	}

//modify
	@GetMapping("/modify/{memberno}")
	public String memberModify(Model model, MemberForm memberForm, @PathVariable("memberno") Integer memberno,
			Principal principal) {

		Member member = ms.getMember(memberno);
		model.addAttribute("member", member);

		if (!member.getMemberid().equals(principal.getName())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정 권한이 없습니다.");
		}

		Member current = ms.getMember(principal.getName());
		boolean isAdmin = "관리자".equals(current.getRole());

		memberForm.setMemberid(member.getMemberid());
		memberForm.setPwd(member.getPwd());
		memberForm.setName(member.getName());
		memberForm.setCellnum(member.getCellnum());
		memberForm.setBirth(member.getBirth());
		memberForm.setEmail(member.getEmail());

		model.addAttribute("관리자", isAdmin);
		model.addAttribute("memberno", memberno);

		return "member_modify";
	}

	@PostMapping("/modify/{memberno}")
	public String memberModify(@Valid MemberForm memberForm, BindingResult bindingResult,
			@PathVariable("memberno") Integer memberno, Principal principal, Model model) {
		memberForm.setMemberno(memberno);

		if (bindingResult.hasErrors()) {
			model.addAttribute("memberForm", memberForm);
			return "member_modify";
		}
		Member member = ms.getMember(memberno);

		if (!member.getMemberid().equals(principal.getName())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정 권한이 없습니다.");
		}
		if (ms.isIdDuplicated(memberForm.getMemberid(), memberForm.getMemberno())) {
			bindingResult.rejectValue("memberid", "duplicate", "이미 사용 중인 아이디입니다.");
			return "member_modify";
		}
		if (ms.isCellnumDuplicated(memberForm.getCellnum(), memberForm.getMemberno())) {
			bindingResult.rejectValue("cellnum", "duplicate", "이미 사용 중인 휴대폰 번호입니다.");
			return "member_modify";
		}
		if (ms.isEmailDuplicated(memberForm.getEmail(), memberForm.getMemberno())) {
			bindingResult.rejectValue("email", "duplicate", "이미 사용 중인 이메일입니다.");
			return "member_modify";
			
		} else { ms.modify(memberno, memberForm.getPwd(), memberForm.getName(), memberForm.getCellnum(), memberForm.getBirth(),
				memberForm.getEmail());
		}
		return "redirect:/member/detail/" + memberno;
	}
	public boolean isMemberidDuplicated(String Memberid,Integer memberno) {
		return mr.existsByMemberidAndMembernoNot(Memberid, memberno);
	}
	public boolean isEmailDuplicated(String email,Integer memberno) {
		return mr.existsByEmailAndMembernoNot(email, memberno);
	}
	public boolean isCellnumDuplicated(String cellnum,Integer memberno) {
		return mr.existsByCellnumAndMembernoNot(cellnum, memberno);
	}

//delete	
	@GetMapping("/delete/{memberno}")
	public String memberDelete(@PathVariable("memberno") Integer memberno) {
		Member member = ms.getMember(memberno);
		ms.remove(member);
		return "redirect:/member/list";
	}

//login,logout
	@GetMapping("/login")
	public String login() {
		return "login_form";
	}

	@GetMapping("/logout")
	public String logout() {
		return "redirect:/member/list";
	}
}
