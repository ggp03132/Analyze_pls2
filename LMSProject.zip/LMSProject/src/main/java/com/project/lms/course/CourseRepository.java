package com.project.lms.course;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.project.lms.category.Category;

public interface CourseRepository extends JpaRepository<Course, Integer> {
	
	Page<Course> findAll(Pageable pageable);
	Page<Course> findAll(Specification<Course> spec, Pageable pageable);
	Page<Course> findByCategory(Category category, Pageable pageable);
}
