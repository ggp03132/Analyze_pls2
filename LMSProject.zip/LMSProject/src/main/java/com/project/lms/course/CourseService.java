package com.project.lms.course;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.project.lms.DataNotFoundException;
import com.project.lms.category.Category;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CourseService {
	
	private final CourseRepository cr;
	
	//테스트
	public Page<Course> getPageListByCategory(Category category, int page, String kw) {
	    List<Sort.Order> sorts = new ArrayList<>();
	    sorts.add(Sort.Order.desc("credate"));
	    Pageable pageable = PageRequest.of(page, 6, Sort.by(sorts));

	    Specification<Course> spec = (Root<Course> q, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
	        query.distinct(true);
	        Predicate predicate = cb.equal(q.get("category"), category); // 카테고리 일치 조건

	        if (kw != null && !kw.trim().isEmpty()) {
	            Predicate keyword = cb.or(
	                cb.like(q.get("title"), "%" + kw + "%"),
	                cb.like(q.get("content"), "%" + kw + "%")
	            );
	            return cb.and(predicate, keyword);  // 카테고리 + 검색어
	        } else {
	            return predicate;  // 검색어 없으면 카테고리만 필터링
	        }
	    };

	    return cr.findAll(spec, pageable);
	}

	
	//검색
	private Specification<Course> search(String kw){
		return new Specification<Course>() {
			
			@Override
			public Predicate toPredicate(Root<Course> q, CriteriaQuery<?> query, CriteriaBuilder cb) {
				query.distinct(true);
				Join<Course, Category> c = q.join("category", JoinType.INNER); //INNER는 Join<a,b>에서 a랑 b 둘 다 일치하는 데이터
				return cb.or(cb.like(q.get("title"), "%" + kw + "%"), //제목검색
						cb.like(q.get("content"), "%" + kw + "%")); //내요ㅕㅇ검색
			}
		};
	}
	
	//목록
	public List<Course> getList(){
		return cr.findAll();
	}
	
	//페이징
	public Page<Course> getPageList(int page, String kw){
		List<Sort.Order> sorts = new ArrayList<>();
		sorts.add(Sort.Order.desc("credate"));
		Pageable pageable = PageRequest.of(page, 6, Sort.by(sorts));
		Specification<Course> spec = search(kw);
		return cr.findAll(spec, pageable);
	}
	
	//상세조회
	public Course getCourse(Integer courseno) {
		Optional<Course> course = cr.findById(courseno);
		if(course.isPresent()) {
			return course.get();
		} else {
			throw new DataNotFoundException("course not found");
		}
	}
	
	//생성
	public void create(String title, String content, String courseimg, Integer grade, String book, String bookimg, Category category) {
		Course course = new Course();
		course.setTitle(title);
		course.setContent(content);
		course.setCourseimg(courseimg);
		course.setGrade(grade);
		course.setBook(book);
		course.setBookimg(bookimg);
		course.setCredate(LocalDateTime.now());
		course.setModdate(LocalDateTime.now());
		course.setCategory(category);
		cr.save(course);
	}
	
	//수정
	public void modify(Course course, String title, String content, String courseimg, Integer grade, String book, String bookimg, Category category) {
		course.setTitle(title);
		course.setContent(content);
		course.setCourseimg(courseimg);
		course.setGrade(grade);
		course.setBook(book);
		course.setBookimg(bookimg);
		course.setCredate(LocalDateTime.now());
		course.setModdate(LocalDateTime.now());
		course.setCategory(category);
		cr.save(course);
	}
	
	//삭제
	public void delete(Course course) {
		cr.delete(course);
	}
}
