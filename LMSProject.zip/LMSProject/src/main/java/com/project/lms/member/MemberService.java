package com.project.lms.member;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.project.lms.DataNotFoundException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MemberService {

	private final MemberRepository mr;
	private final PasswordEncoder pe;

	public void create(String memberid, String pwd, String name, String cellnum, String birth, String email) {
		Member m = new Member();
		m.setMemberid(memberid);
		m.setPwd(pe.encode(pwd)); // pe.encode 암호화
		m.setName(name);
		m.setCellnum(cellnum);
		m.setBirth(birth);
		m.setEmail(email);
		m.setRole(Role.fromValue(1));
		m.setCreDate(LocalDateTime.now());
		m.setModDate(LocalDateTime.now());
		mr.save(m);
	}

	public Page<Member> getList(int page) {
		List<Sort.Order> sorts = new ArrayList<>();
		sorts.add(Sort.Order.desc("creDate"));

		Pageable pageable = PageRequest.of(page, 10, Sort.by(sorts));
		return mr.findAll(pageable);

	}

	public Member getMember(String memberid) {
		System.out.println("Searching for memberid: " + memberid);

		Optional<Member> om = mr.findByMemberid(memberid);

		if (om.isPresent()) {
			return om.get();
		} else {
			throw new DataNotFoundException("해당 ID의 회원이 존재하지 않습니다.");
		}
	}

	public Member getMember(Integer memberno) {
		return mr.findById(memberno)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "해당 회원이 존재하지 않습니다."));
	}

	// 중복 체크, memberid는 수정시 예외
	public boolean isIdDuplicated(String memberid, Integer memberno) {
		if (memberno == null) { // 신규 가입 시: userid가 DB에 존재하면 중복 true 반환
			return mr.findByMemberid(memberid).isPresent();
		} else {
			Optional<Member> memberOpt = mr.findByMemberid(memberid);
			if (memberOpt.isEmpty()) {
				return false; // DB에 userid가 없으니 중복 아님
			}
			Member member = memberOpt.get();
			return !member.getMemberno().equals(memberno); // 다르면 중복
		}
	}

	public boolean isCellnumDuplicated(String cellnum, Integer memberno) {
		if (memberno == null) {
			return mr.findByCellnum(cellnum).isPresent();
		} else {
			Optional<Member> memberOpt = mr.findByCellnum(cellnum);
			if (memberOpt.isEmpty()) {
				return false;
			}
			Member member = memberOpt.get();
			return !member.getMemberno().equals(memberno);
		}
	}

	public boolean isEmailDuplicated(String email, Integer memberno) {
		if (memberno == null) {
			return mr.findByEmail(email).isPresent();
		} else {
			Optional<Member> memberOpt = mr.findByEmail(email);
			if (memberOpt.isEmpty()) {
				return false;
			}
			Member member = memberOpt.get();
			return !member.getMemberno().equals(memberno);
		}
	}	

	public void modify(Integer memberno, String pwd, String name, String cellnum, String birth, String email) {
		Member m = getMember(memberno);

		m.setPwd(pe.encode(pwd));
		m.setName(name);
		m.setCellnum(cellnum);
		m.setBirth(birth);
		m.setEmail(email);
		m.setRole(Role.fromValue(1));
		m.setCreDate(LocalDateTime.now());
		m.setModDate(LocalDateTime.now());
		mr.save(m);
	}

	public void remove(Member member) {
		mr.delete(member);
	}

}
